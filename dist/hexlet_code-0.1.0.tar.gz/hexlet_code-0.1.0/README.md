[![Maintainability](https://api.codeclimate.com/v1/badges/c73c6497b7dcf1f2d39b/maintainability)](https://codeclimate.com/github/tgafiulin/python-project-49/maintainability)

### Hexlet tests and linter status:
[![Actions Status](https://github.com/tgafiulin/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/tgafiulin/python-project-49/actions)